<!DOCTYPE html>
<html>
<head>
	<title>QuaranTeam Home Page</title>
</head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

		<style type="text/css">
	
	body{
			font-family: Arial, Helvetica, sans-serif;
			margin: 0;
			padding: 20px;
			background-image: url("/pictures/b1.jpg");
			background-size: cover;
	}
	.head{
		background-color: turquoise;
		padding: 20px;
		font-family: hinting;
		font-size: 30px;
		font-style: bold;
	}
	.footer{
		background-color: turquoise;
		padding: 10px;
		font-family: hinting;
		font-size: 15px;
		font-style: bold;
		text-align: center;
		margin-top: 15px;
	}
	
	a{
		text-decoration: none;
		border: 3px solid black;
		background: deepskyblue;
		padding: 10px;
		border-radius: 100px 0px 0px 100px;
		font-family: Arial Black;
		color: white;
	}

	h1{
		font-family: cursive;
		color: black;
	}
	h6{
		font-family: Arial;
		border: 2px solid black;
		background-color: crimson;
		width: 500px;
		padding: 1px;
		color: white;
	}
	h2 {
		font-family: verdana;
		color: cyan;
	}
	h3 {
		font-family: verdana;
		color: white;
	}

	.c1,.c2{
		background-color: darkturquoise;
	}
	.cc1:hover,.cc2:hover {
		background-image: linear-gradient(white, darkturquoise, white);
			background-color: transparent;
	}

	tr{
		text-align: center;
		font-size: 18px;
	}
	sup{
		color: white;
	}
	a {
		text-decoration: none;
		color: white;
	}
	td {
		border: 2px solid white;
			font-family: verdana;

	}
	
	p {
		text-align: bottom;
		

	}
	


	</style>

<header>
		<center><h1 class="head">QuaranTeam</h1>

	<nav class="navbar navbar-expand-lg navbar-light ">
  <div class="collapse navbar-collapse" id="navbarNavDropdown">
      <li class="nav-item">
        <a class="nav-link" href="/home">Home</a>
      </li>
	  <div class="collapse navbar-collapse" id="navbarNavDropdown">
      <li class="nav-item">
        <a class="nav-link" href="/about">About</a>
      </li>
	  <div class="collapse navbar-collapse" id="navbarNavDropdown">
      <li class="nav-item">
        <a class="nav-link" href="/contact">Contact</a>
      </li>
     
  </div>
</nav>
</center>
	</header>


<body>
	<br><br><br><br><br><br><br><br>

	<center>
			<h1>
			<b style="font-family: century gothic; 
				border: 3px solid black; 
				background-color: transparent; 
				padding: 20px;
				font-style: italic;
				text-shadow: 4px 2px 1px black; 
				color: white;
				font-size: 100px;
				">
				Welcome to our Home Page!</b>
			</h1></p>
		</center>


		<center>
	
<br><br><br><br><br><br>

<table border="3" style="border-style:none;" cellspacing="20" cellpadding="10" width="70%" >


<tr>
	<td class="c1" title="ABOUT"> 	<b style="color: white">ABOUT PAGE</b></td>
	<td class="cc1" title="Click me">				<a href="link/about.html">Here</a></td>
</tr>

<tr>
	<td class="c2" title="Contacts"> 		<b style="color: white">CONTACT PAGE</b></td>
	<td class="cc2" title="Click me">				<a href="link/contact.html">Here</a></td>
</tr>



</table>
</center>

<br>



 		<center>
			<h1>
			<b style="font-family: century gothic; 
				border: 3px solid black; 
				background-color: transparent; 
				padding: 5px; 
				color: black;
				font-size: 15px;
				">
				Group QuaranTeam</b>
			</h1></p>
		</center>
		<br><br><br><br><br><br>
      



</body>
<footer>
		<p class="footer">QuaranTeam@2020<p>
	</footer>
</html>